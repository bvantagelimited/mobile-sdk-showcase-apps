//
//  GetCodeDelegate.swift
//  IPificationSDK-Demo
//
//  Created by Nguyen Huu Tinh on 10/2/2021.
//  Copyright © 2021 Nguyen Huu Tinh. All rights reserved.
//

import Foundation



protocol GetCodeDelegate {
    func getCode(_ code: String)
}
